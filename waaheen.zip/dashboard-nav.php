
    <div class="container px-md-4 my-5 pt-5" >
        <h3 class='mb-4 text-center fw-bold'>Business Dashboard</h3>

        <div class="row mx-md-1">
            <div class="d-flex justify-content-center justify-items-center dashbord-menu-wrapper">
                <a href="dashboard.php" class="border light-bg radius text-center w-100 float-start">Analyzing</a>
                <a href="dashboard-products.php" class="border light-bg radius text-center w-100 float-start">Products</a>
                <!-- <a href="dashboard-posts.php" class="border light-bg radius text-center w-100 float-start">Posts</a> -->
                <a href="dashboard-followers.php" class="border light-bg radius text-center w-100 float-start">Followers</a>
                <a href="dashboard-following.php" class="border light-bg radius text-center w-100 float-start">Following</a>
            </div>
        </div>
    </div>
    
 
    
    