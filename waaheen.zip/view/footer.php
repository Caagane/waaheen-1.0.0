
    

<!-- fontawsome -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" ></script>

<!-- Option 1: Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>


<!-- JQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>



<!-- Other JS Files -->

<script src="js/Users.js"></script>
<script src="js/productsCategories.js"></script>
<script src="js/signin_signup.js"></script>
<script src="js/custom.js"></script>

<script>
  $(document).ready(function () {
      
    // Load all notifications
    userLocation();

    setTimeout(google, 3000);
    setTimeout(facebook, 3000);
    setTimeout(notifications, 5000);



  });
</script>

</body>
</html>