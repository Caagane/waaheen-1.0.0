
    

<!-- fontawsome -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" ></script>
<!-- bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" ></script>
<!-- JQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>



<!-- Other JS Files -->

<script src="js/Users.js"></script>
<script src="js/productsCategories.js"></script>
<script src="js/signin_signup.js"></script>
<script src="js/custom.js"></script>

<script>
  $(document).ready(function () {
      
    // Load all notifications
    notifications();


  });


</script>

</body>
</html>