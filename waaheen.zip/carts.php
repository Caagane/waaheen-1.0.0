<?php include('./view/header.php'); ?>


    <div class="container m-auto justify-content-center my-5 py-5" id="carts">
    </div>


<?php include('./view/footer.php'); ?>

<script>
  $(document).ready(function () {

    // call all carts
    carts();

  });
</script>