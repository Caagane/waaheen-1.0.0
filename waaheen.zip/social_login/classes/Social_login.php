<?php
include_once('../classes/DB_conn.php');
 
class Social_login extends DbConnection{

    public function __construct(){

        parent::__construct();
    }

    public function fb_login($fbid, $fbfullname, $fbemail, $fbpic){
        
        $fbid = $this->con->real_escape_string($fbid);
        $fbfullname = $this->con->real_escape_string($fbfullname);
        $fbemail = $this->con->real_escape_string($fbemail);
        $fbpic = $this->con->real_escape_string($fbpic);

        $query = "SELECT * FROM users WHERE social_id = '$fbid' AND login_type='facebook'";
        $sql = $this->con->query($query);

        if($sql->num_rows < 1){
            $query="INSERT INTO users(social_id,f_name,email,image,login_type) VALUES('$fbid','$fbfullname','$fbemail','$fbpic','facebook')";
            $sql = $this->con->query($query);

            // login
            $query = "SELECT * FROM users WHERE social_id = '$fbid' AND login_type='facebook'";
            $sql = $this->con->query($query);
    
            if($sql->num_rows > 0){
                $row = $sql->fetch_array();
                return $row['id'];
            }
            else{
                return false;
            }
        }
        else{
            $query="UPDATE users SET f_name='$fbfullname', email='$fbemail', image='$fbpic' where social_id='$fbid'";
            $sql = $this->con->query($query);
            
            // login
            $query = "SELECT * FROM users WHERE social_id = '$fbid' AND login_type='facebook'";
            $sql = $this->con->query($query);
    
            if($sql->num_rows > 0){
                $row = $sql->fetch_array();
                return $row['id'];
            }
            else{
                return false;
            }
        }
    }

    
    public function google_login($id, $full_name, $email, $profile_pic){
        
        $id = $this->con->real_escape_string($id);
        $full_name = $this->con->real_escape_string($full_name);
        $email = $this->con->real_escape_string($email);
        $profile_pic = $this->con->real_escape_string($profile_pic);

        $query = "SELECT * FROM users WHERE social_id = '$id' AND login_type='google'";
        $sql = $this->con->query($query);

        if($sql->num_rows < 1){
            $query="INSERT INTO users (social_id,f_name,email,image,login_type) VALUES('$id','$full_name','$email','$profile_pic','google')";
            $sql = $this->con->query($query);

            // login
            $query = "SELECT * FROM users WHERE social_id = '$id' AND login_type='google'";
            $sql = $this->con->query($query);
    
            if($sql->num_rows > 0){
                $row = $sql->fetch_array();
                return $row['id'];
            }
            else{
                return false;
            }
        }
        else{
            $query="UPDATE users SET f_name='$full_name', email='$email', image='$profile_pic' where social_id='$id'";
            $sql = $this->con->query($query);
            
            // login
            $query = "SELECT * FROM users WHERE social_id = '$id' AND login_type='google'";
            $sql = $this->con->query($query);
    
            if($sql->num_rows > 0){
                $row = $sql->fetch_array();
                return $row['id'];
            }
            else{
                return false;
            }
        }
    }
    
        
    public function details($sql){

        $sql = $this->con->query($query);
        
        $row = $sql->fetch_array();
            
        return $row;       
    }
    
    public function escape_string($value){
        
        return $this->connection->real_escape_string($value);
    }
}