<?php
session_start();

include 'classes/Social_login.php';
	
$Social_login = new Social_login();

require 'php-graph-sdk/src/Facebook/autoload.php';

$fb = new Facebook\Facebook([
'app_id'      => '313791853972473',
'app_secret'     => '56e24724f0582831b98a7596d8eb5742',
'default_graph_version'  => 'v2.10'
]);

$helper = $fb->getRedirectLoginHelper();
$permissions = ['email']; // optional

if(isset($_GET['code'])){

    try {
        if (isset($_SESSION['facebook_access_token'])) {
            $accessToken = $_SESSION['facebook_access_token'];
        } else {
            $accessToken = $helper->getAccessToken();
        }
    } catch(Facebook\Exceptions\facebookResponseException $e) {
        // When Graph returns an error
        echo 'Graph returned an error: ' . $e->getMessage();
        exit;
    } catch(Facebook\Exceptions\FacebookSDKException $e) {
        // When validation fails or other local issues
        echo 'Facebook SDK returned an error: ' . $e->getMessage();
        exit;
    }
    if (isset($accessToken)) {
        if (isset($_SESSION['facebook_access_token'])) {
        $fb->setDefaultAccessToken($_SESSION['facebook_access_token']);
        } else {
        // getting short-lived access token
        $_SESSION['facebook_access_token'] = (string) $accessToken;
        // OAuth 2.0 client handler
        $oAuth2Client = $fb->getOAuth2Client();
        // Exchanges a short-lived access token for a long-lived one
        $longLivedAccessToken = $oAuth2Client->getLongLivedAccessToken($_SESSION['facebook_access_token']);
        $_SESSION['facebook_access_token'] = (string) $longLivedAccessToken;
        // setting default access token to be used in script
        $fb->setDefaultAccessToken($_SESSION['facebook_access_token']);
        }
        // redirect the user to the profile page if it has "code" GET variable
        if (isset($_GET['code'])) {
            header('Location:  ../');
        }
        // getting basic info about user
        try {
            $profile_request = $fb->get('/me?fields=name,first_name,last_name,email');
            $requestPicture = $fb->get('/me/picture?redirect=false&height=200'); //getting user picture
            $picture = $requestPicture->getGraphUser();
            $profile = $profile_request->getGraphUser();
            $fbid = $profile->getProperty('id');           // To Get Facebook ID
            $fbfullname = $profile->getProperty('name');   // To Get Facebook full name
            $fbemail = $profile->getProperty('email');    //  To Get Facebook email
            $fbpic = $picture['url'];


            // Send all user data into class to save into database
            $auth = $Social_login->fb_login($fbid, $fbfullname, $fbemail, $fbpic);
            $_SESSION['waaheen_user_id'] = $auth;


        } catch(Facebook\Exceptions\FacebookResponseException $e) {
            // When Graph returns an error
            echo 'Graph returned an error: ' . $e->getMessage();
            session_destroy();
            // redirecting user back to app login page
            header("Location: ../");
            exit;
            } catch(Facebook\Exceptions\FacebookSDKException $e) {
            // When validation fails or other local issues
            echo 'Facebook SDK returned an error: ' . $e->getMessage();
            exit;
        }
    }
} else {
    if ($_SESSION['waaheen_user_id'] != 0) {
        header("Location: ../");
    } else {
        // replace your website URL same as added in the developers.Facebook.com/apps e.g. if you used http instead of https and you used            
        $loginUrl = $helper->getLoginUrl('http://localhost/waaheen/social_login/facebook.php', $permissions);
        echo '<a href="' . $loginUrl . '" class="w-100 btn btn-lg p-2 btn-primary btn-floating my-1"><i class="fab fa-facebook-f p-2"></i> Facebook</a>';
    }
}
?>