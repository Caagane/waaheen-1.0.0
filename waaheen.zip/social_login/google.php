<?php
session_start();

include 'classes/Social_login.php';
	
$Social_login = new Social_login();

require 'google-api/vendor/autoload.php';

// Creating new google client instance
$client = new Google_Client();

// Enter your Client ID
$client->setClientId('286011292186-0u3um4o8ebridtf0nsvrpjkabri9ae2g.apps.googleusercontent.com');
// Enter your Client Secrect
$client->setClientSecret('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');
// Enter the Redirect URL
$client->setRedirectUri('http://localhost/waaheen/social_login/google.php');

// Adding those scopes which we want to get (email & profile Information)
$client->addScope("email");
$client->addScope("profile");


if(isset($_GET['code'])):

    $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);

    if(!isset($token["error"])){

        $client->setAccessToken($token['access_token']);

        // getting profile information
        $google_oauth = new Google_Service_Oauth2($client);
        $google_account_info = $google_oauth->userinfo->get();
    
        // Storing data into database
        $id = $google_account_info->id;
        $full_name = $google_account_info->name;
        $email = $google_account_info->email;
        $profile_pic = $google_account_info->picture;

        // Send all user data into class to save into database
        $auth = $Social_login->google_login($id, $full_name, $email, $profile_pic);
        $_SESSION['waaheen_user_id'] = $auth;

        
        header('Location: ../');

    }
    else{
        header('Location: ../');
        exit;
    }
    
else: 
    // Google Login Url = $client->createAuthUrl(); 
    if ($_SESSION['waaheen_user_id'] == 0) {
        ?>
        <a href="<?php echo $client->createAuthUrl(); ?>" class="w-100 btn btn-lg p-2 btn-light border btn-floating"><i class="fab fa-google p-2"></i> Google</a>

        <?php
    }
?>

    

<?php endif; ?>